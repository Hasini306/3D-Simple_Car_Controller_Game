using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// The centre line of the road. Built from a few control points that are smoothed into a curve.
/// Distance along the road is measured in metres from the start.
/// </summary>
public class TrackPath
{
    public const float Step = 2f;
    public readonly List<Vector3> Points = new List<Vector3>();

    public float Length { get { return (Points.Count - 1) * Step; } }

    public TrackPath(Vector3[] control)
    {
        List<Vector3> dense = new List<Vector3>();
        int n = control.Length;
        for (int i = 0; i < n - 1; i++)
        {
            Vector3 p0 = control[Mathf.Max(i - 1, 0)];
            Vector3 p1 = control[i];
            Vector3 p2 = control[i + 1];
            Vector3 p3 = control[Mathf.Min(i + 2, n - 1)];
            for (int s = 0; s < 40; s++)
                dense.Add(CatmullRom(p0, p1, p2, p3, s / 40f));
        }
        dense.Add(control[n - 1]);

        // Re-sample so points are exactly Step metres apart.
        Points.Add(dense[0]);
        float travelled = 0f;
        float target = Step;
        for (int i = 1; i < dense.Count; i++)
        {
            Vector3 a = dense[i - 1];
            Vector3 b = dense[i];
            float seg = Vector3.Distance(a, b);
            if (seg < 0.0001f) continue;
            while (travelled + seg >= target)
            {
                float t = (target - travelled) / seg;
                Points.Add(Vector3.Lerp(a, b, t));
                target += Step;
            }
            travelled += seg;
        }
    }

    static Vector3 CatmullRom(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t)
    {
        float t2 = t * t;
        float t3 = t2 * t;
        return 0.5f * ((2f * p1) + (-p0 + p2) * t + (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 + (-p0 + 3f * p1 - 3f * p2 + p3) * t3);
    }

    Vector3 Tangent(int i)
    {
        int last = Points.Count - 1;
        int a = Mathf.Max(i - 1, 0);
        int b = Mathf.Min(i + 1, last);
        Vector3 d = Points[b] - Points[a];
        d.y = 0f;
        return d.normalized;
    }

    /// <summary>Gets a world position and forward direction at a distance along the road.
    /// lateral = sideways offset in metres (positive = right of the driving direction).</summary>
    public void Evaluate(float dist, float lateral, out Vector3 pos, out Vector3 fwd)
    {
        int last = Points.Count - 1;
        float f = dist / Step;
        if (f <= 0f)
        {
            fwd = Tangent(0);
            pos = Points[0] + fwd * dist;
        }
        else if (f >= last)
        {
            fwd = Tangent(last);
            pos = Points[last] + fwd * (dist - Length);
        }
        else
        {
            int i = (int)f;
            float t = f - i;
            pos = Vector3.Lerp(Points[i], Points[i + 1], t);
            fwd = Vector3.Lerp(Tangent(i), Tangent(i + 1), t).normalized;
        }
        Vector3 right = Vector3.Cross(Vector3.up, fwd).normalized;
        pos += right * lateral;
        pos.y = 0f;
    }

    /// <summary>Finds how far along the road a world position is (searches near a hint distance).</summary>
    public float Project(Vector3 p, float hintDist)
    {
        int last = Points.Count - 1;
        int center = Mathf.Clamp(Mathf.RoundToInt(hintDist / Step), 0, last);
        int from = Mathf.Max(0, center - 60);
        int to = Mathf.Min(last, center + 60);
        float best = float.MaxValue;
        int bestIndex = center;
        for (int i = from; i <= to; i++)
        {
            float dx = Points[i].x - p.x;
            float dz = Points[i].z - p.z;
            float sq = dx * dx + dz * dz;
            if (sq < best) { best = sq; bestIndex = i; }
        }
        return bestIndex * Step;
    }

    public Bounds GetBounds()
    {
        Bounds b = new Bounds(Points[0], Vector3.zero);
        for (int i = 1; i < Points.Count; i++) b.Encapsulate(Points[i]);
        return b;
    }
}

using UnityEngine;

/// <summary>Holds references to the wheels / lights created for a car model.</summary>
public class CarParts
{
    public Transform[] frontPivots;
    public Transform[] spinners;
    public Renderer[] tailLights;
    public Material tailOn;
    public Material tailOff;
}

/// <summary>Builds car models out of Unity primitives (box body, cylinder wheels).</summary>
public static class CarBuilder
{
    static Material M(string name, float r, float g, float b)
    {
        return GameUtil.GetMaterial(name, new Color(r, g, b, 1f));
    }

    public static CarParts BuildVisual(Transform root, Color bodyColor, string colorKey, bool uniqueTail)
    {
        Material body = GameUtil.GetMaterial("CarBody" + colorKey, bodyColor);
        Material glass = M("CarGlass", 0.08f, 0.12f, 0.18f);
        Material tire = M("Tire", 0.05f, 0.05f, 0.05f);
        Material rim = M("Rim", 0.75f, 0.75f, 0.78f);
        Material dark = M("Dark", 0.1f, 0.1f, 0.1f);
        Material head = M("HeadLight", 1f, 1f, 0.85f);
        Color tailOffColor = new Color(0.45f, 0.05f, 0.05f, 1f);
        Color tailOnColor = new Color(1f, 0.1f, 0.1f, 1f);
        Material tailOff = uniqueTail ? GameUtil.NewMaterial("TailLightOff", tailOffColor) : GameUtil.GetMaterial("TailLightOff", tailOffColor);
        Material tailOn = uniqueTail ? GameUtil.NewMaterial("TailLightOn", tailOnColor) : GameUtil.GetMaterial("TailLightOn", tailOnColor);

        Transform t = root;
        GameUtil.Visual(PrimitiveType.Cube, "Body", t, new Vector3(0f, 0.62f, 0f), new Vector3(1.8f, 0.55f, 4.2f), body);
        GameUtil.Visual(PrimitiveType.Cube, "Hood", t, new Vector3(0f, 0.93f, 1.3f), new Vector3(1.7f, 0.08f, 1.3f), body);
        GameUtil.Visual(PrimitiveType.Cube, "Cabin", t, new Vector3(0f, 1.12f, -0.3f), new Vector3(1.52f, 0.5f, 2.2f), glass);
        GameUtil.Visual(PrimitiveType.Cube, "Roof", t, new Vector3(0f, 1.39f, -0.3f), new Vector3(1.58f, 0.06f, 2.0f), body);
        GameUtil.Visual(PrimitiveType.Cube, "BumperFront", t, new Vector3(0f, 0.45f, 2.12f), new Vector3(1.85f, 0.22f, 0.2f), dark);
        GameUtil.Visual(PrimitiveType.Cube, "BumperRear", t, new Vector3(0f, 0.45f, -2.12f), new Vector3(1.85f, 0.22f, 0.2f), dark);
        GameUtil.Visual(PrimitiveType.Cube, "HeadLightL", t, new Vector3(-0.65f, 0.72f, 2.11f), new Vector3(0.38f, 0.18f, 0.06f), head);
        GameUtil.Visual(PrimitiveType.Cube, "HeadLightR", t, new Vector3(0.65f, 0.72f, 2.11f), new Vector3(0.38f, 0.18f, 0.06f), head);
        Renderer tl = GameUtil.Visual(PrimitiveType.Cube, "TailLightL", t, new Vector3(-0.65f, 0.72f, -2.11f), new Vector3(0.38f, 0.18f, 0.06f), tailOff).GetComponent<Renderer>();
        Renderer tr = GameUtil.Visual(PrimitiveType.Cube, "TailLightR", t, new Vector3(0.65f, 0.72f, -2.11f), new Vector3(0.38f, 0.18f, 0.06f), tailOff).GetComponent<Renderer>();

        Transform[] pivots = new Transform[4];
        Transform[] spinners = new Transform[4];
        float[] xs = { -0.9f, 0.9f, -0.9f, 0.9f };
        float[] zs = { 1.3f, 1.3f, -1.3f, -1.3f };
        for (int i = 0; i < 4; i++)
        {
            GameObject piv = new GameObject("Wheel" + i);
            piv.transform.SetParent(t, false);
            piv.transform.localPosition = new Vector3(xs[i], 0.41f, zs[i]);
            GameObject spin = new GameObject("Spin");
            spin.transform.SetParent(piv.transform, false);
            GameObject tyre = GameUtil.Visual(PrimitiveType.Cylinder, "Tyre", spin.transform, Vector3.zero, new Vector3(0.7f, 0.125f, 0.7f), tire);
            tyre.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            GameObject rimObj = GameUtil.Visual(PrimitiveType.Cylinder, "Rim", spin.transform, Vector3.zero, new Vector3(0.4f, 0.135f, 0.4f), rim);
            rimObj.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            float side = xs[i] < 0f ? -1f : 1f;
            GameUtil.Visual(PrimitiveType.Cube, "Spoke", spin.transform, new Vector3(side * 0.15f, 0f, 0f), new Vector3(0.05f, 0.5f, 0.1f), dark);
            pivots[i] = piv.transform;
            spinners[i] = spin.transform;
        }

        CarParts parts = new CarParts();
        parts.frontPivots = new Transform[] { pivots[0], pivots[1] };
        parts.spinners = spinners;
        parts.tailLights = new Renderer[] { tl, tr };
        parts.tailOn = tailOn;
        parts.tailOff = tailOff;
        return parts;
    }

    static void AddBodyCollider(GameObject car)
    {
        BoxCollider col = car.AddComponent<BoxCollider>();
        col.center = new Vector3(0f, 0.65f, 0f);
        col.size = new Vector3(1.8f, 1.3f, 4.2f);
    }

    public static CarController CreatePlayerCar(Transform parent, Vector3 pos, Quaternion rot)
    {
        GameObject car = new GameObject("PlayerCar");
        car.transform.SetParent(parent, false);
        car.transform.SetPositionAndRotation(pos, rot);
        car.tag = "Player";
        CarParts parts = BuildVisual(car.transform, new Color(0.85f, 0.1f, 0.1f), "Player", true);
        car.AddComponent<Rigidbody>();
        BoxCollider col = car.AddComponent<BoxCollider>();
        col.center = new Vector3(0f, 0.65f, 0f);
        col.size = new Vector3(1.8f, 1.3f, 4.2f);
        PhysicMaterial pm = new PhysicMaterial("CarSlippery");
        pm.dynamicFriction = 0f;
        pm.staticFriction = 0f;
        pm.bounciness = 0f;
        pm.frictionCombine = PhysicMaterialCombine.Minimum;
        col.material = pm;
        CarController cc = car.AddComponent<CarController>();
        cc.frontWheelPivots = parts.frontPivots;
        cc.wheelSpinners = parts.spinners;
        cc.tailLights = parts.tailLights;
        cc.tailLightOn = parts.tailOn;
        cc.tailLightOff = parts.tailOff;
        return cc;
    }

    public static void CreateStaticCar(Transform parent, Vector3 pos, Quaternion rot, Color color, string key)
    {
        GameObject car = new GameObject("BrokenDownCar");
        car.transform.SetParent(parent, false);
        car.transform.SetPositionAndRotation(pos, rot);
        BuildVisual(car.transform, color, key, false);
        AddBodyCollider(car);
    }

    public static void CreateTrafficCar(Transform parent, TrackPath path, float dist, float lateral, float speed, float endDist, Color color, string key)
    {
        Vector3 pos, fwd;
        path.Evaluate(dist, lateral, out pos, out fwd);
        GameObject car = new GameObject("TrafficCar");
        car.transform.SetParent(parent, false);
        car.transform.SetPositionAndRotation(pos, Quaternion.LookRotation(fwd, Vector3.up));
        BuildVisual(car.transform, color, key, false);
        Rigidbody rb = car.AddComponent<Rigidbody>();
        rb.isKinematic = true;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        AddBodyCollider(car);
        TrafficCar tc = car.AddComponent<TrafficCar>();
        tc.path = path;
        tc.distance = dist;
        tc.lateral = lateral;
        tc.speed = speed;
        tc.endDistance = endDist;
    }
}

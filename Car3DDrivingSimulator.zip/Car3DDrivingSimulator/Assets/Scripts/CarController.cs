using System;
using UnityEngine;

/// <summary>
/// Rigidbody-based car. Keyboard: W/Up = accelerate, S/Down = reverse, A/D or Left/Right = steer, Space = brake.
/// On-screen buttons are read from MobileCarControls.
/// The car cannot flip (X/Z rotation is locked) and the wheels are visual only (they spin and steer).
/// </summary>
[RequireComponent(typeof(Rigidbody))]
public class CarController : MonoBehaviour
{
    [Header("Speed (metres per second)")]
    public float maxSpeed = 28f;
    public float maxReverseSpeed = 9f;
    public float acceleration = 8f;
    public float brakeDeceleration = 24f;
    public float coastDeceleration = 2.5f;

    [Header("Steering")]
    public float maxSteerAngle = 30f;   // how far the front wheels visually turn
    public float turnRate = 80f;        // degrees per second at full steering
    public float steerSpeed = 5f;       // how quickly the steering reacts
    public float sidewaysGrip = 8f;     // higher = less sliding

    [Header("Wheels (visual only)")]
    public Transform[] frontWheelPivots;
    public Transform[] wheelSpinners;
    public float wheelRadius = 0.35f;

    [Header("Brake lights")]
    public Renderer[] tailLights;
    public Material tailLightOn;
    public Material tailLightOff;

    [HideInInspector] public bool inputEnabled;

    /// <summary>Raised on a hard impact. The value is the impact speed.</summary>
    public event Action<float> OnCrash;

    public float ForwardSpeed { get; private set; }
    public float SpeedKmh { get { return Mathf.Abs(ForwardSpeed) * 3.6f; } }

    Rigidbody rb;
    float throttleInput, steerInput, steerSmooth;
    bool brakeInput;
    float wheelAngle;
    AudioSource engine;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.mass = 1200f;
        rb.centerOfMass = new Vector3(0f, 0.4f, 0f);
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        CreateEngineSound();
    }

    void CreateEngineSound()
    {
        // A simple engine hum generated in code (no audio files needed).
        int rate = 44100;
        float[] data = new float[rate];
        for (int i = 0; i < rate; i++)
        {
            float t = (float)i / rate;
            data[i] = 0.45f * Mathf.Sin(2f * Mathf.PI * 55f * t)
                    + 0.30f * Mathf.Sin(2f * Mathf.PI * 110f * t)
                    + 0.20f * Mathf.Sin(2f * Mathf.PI * 165f * t);
        }
        AudioClip clip = AudioClip.Create("EngineHum", rate, 1, rate, false);
        clip.SetData(data, 0);
        engine = gameObject.AddComponent<AudioSource>();
        engine.clip = clip;
        engine.loop = true;
        engine.spatialBlend = 0f;
        engine.volume = 0f;
        engine.Play();
    }

    void Update()
    {
        ReadInput();
        steerSmooth = Mathf.MoveTowards(steerSmooth, steerInput, steerSpeed * Time.deltaTime);
        UpdateWheelVisuals();
        UpdateTailLights();
        if (engine != null)
        {
            float ratio = Mathf.Clamp01(SpeedKmh / 100f);
            engine.pitch = Mathf.Lerp(0.8f, 2.6f, ratio);
            engine.volume = inputEnabled ? 0.12f + 0.12f * Mathf.Abs(throttleInput) : 0f;
        }
    }

    void ReadInput()
    {
        if (!inputEnabled)
        {
            throttleInput = 0f; steerInput = 0f; brakeInput = false;
            return;
        }
        float t = 0f;
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow) || MobileCarControls.Accelerate) t += 1f;
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow) || MobileCarControls.Reverse) t -= 1f;
        float s = 0f;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow) || MobileCarControls.Right) s += 1f;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow) || MobileCarControls.Left) s -= 1f;
        throttleInput = t;
        steerInput = s;
        brakeInput = Input.GetKey(KeyCode.Space) || MobileCarControls.Brake;
    }

    void UpdateWheelVisuals()
    {
        wheelAngle = Mathf.Repeat(wheelAngle + (ForwardSpeed / wheelRadius) * Mathf.Rad2Deg * Time.deltaTime, 360f);
        if (wheelSpinners != null)
            for (int i = 0; i < wheelSpinners.Length; i++)
                if (wheelSpinners[i] != null) wheelSpinners[i].localRotation = Quaternion.Euler(wheelAngle, 0f, 0f);
        if (frontWheelPivots != null)
            for (int i = 0; i < frontWheelPivots.Length; i++)
                if (frontWheelPivots[i] != null) frontWheelPivots[i].localRotation = Quaternion.Euler(0f, steerSmooth * maxSteerAngle, 0f);
    }

    void UpdateTailLights()
    {
        if (tailLights == null || tailLightOn == null || tailLightOff == null) return;
        bool on = brakeInput || throttleInput < -0.01f;
        for (int i = 0; i < tailLights.Length; i++)
            if (tailLights[i] != null) tailLights[i].sharedMaterial = on ? tailLightOn : tailLightOff;
    }

    void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;
        Quaternion rot = rb.rotation;
        Vector3 localVel = Quaternion.Inverse(rot) * rb.velocity;
        float fwd = localVel.z;

        if (inputEnabled)
        {
            if (brakeInput)
            {
                fwd = Mathf.MoveTowards(fwd, 0f, brakeDeceleration * dt);
            }
            else if (throttleInput > 0.01f)
            {
                if (fwd < -0.5f) fwd = Mathf.MoveTowards(fwd, 0f, brakeDeceleration * dt);
                else if (fwd < maxSpeed)
                {
                    float k = Mathf.Lerp(1f, 0.3f, Mathf.Clamp01(fwd / maxSpeed));
                    fwd = Mathf.Min(maxSpeed, fwd + acceleration * k * dt);
                }
            }
            else if (throttleInput < -0.01f)
            {
                if (fwd > 0.5f) fwd = Mathf.MoveTowards(fwd, 0f, brakeDeceleration * dt);
                else if (fwd > -maxReverseSpeed) fwd = Mathf.Max(-maxReverseSpeed, fwd - acceleration * 0.6f * dt);
            }
            else
            {
                fwd = Mathf.MoveTowards(fwd, 0f, coastDeceleration * dt);
            }
        }
        else
        {
            fwd = Mathf.MoveTowards(fwd, 0f, brakeDeceleration * 0.6f * dt);
        }

        localVel.z = fwd;
        localVel.x = Mathf.Lerp(localVel.x, 0f, 1f - Mathf.Exp(-sidewaysGrip * dt)); // tyre grip
        rb.velocity = rot * localVel;

        // Steering: the car only turns while moving, and a little less at high speed.
        float speedFactor = Mathf.Clamp(fwd / 5f, -1f, 1f);
        float highSpeed = Mathf.Lerp(1f, 0.45f, Mathf.Clamp01(Mathf.Abs(fwd) / maxSpeed));
        float yawDegPerSec = steerSmooth * turnRate * speedFactor * highSpeed;
        rb.angularVelocity = new Vector3(0f, yawDegPerSec * Mathf.Deg2Rad, 0f);

        ForwardSpeed = fwd;
    }

    void OnCollisionEnter(Collision c)
    {
        if (c.contactCount > 0 && c.GetContact(0).normal.y > 0.6f) return; // just the ground
        Rigidbody other = c.rigidbody;
        if (other != null && !other.isKinematic && other.mass < 50f) return; // light objects like cones
        float impact = c.relativeVelocity.magnitude;
        if (impact < 2.5f) return;
        if (OnCrash != null) OnCrash(impact);
    }

    public void ResetCar(Vector3 pos, Quaternion rot)
    {
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        rb.position = pos;
        rb.rotation = rot;
        transform.SetPositionAndRotation(pos, rot);
        steerSmooth = 0f;
        ForwardSpeed = 0f;
    }
}

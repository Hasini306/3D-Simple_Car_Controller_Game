using UnityEngine;

/// <summary>Third-person camera that stays behind the car and smoothly follows its turning.</summary>
[RequireComponent(typeof(Camera))]
public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public CarController car;
    public Vector3 offset = new Vector3(0f, 3.2f, -7.5f);
    public float yawSmooth = 4f;
    public float lookHeight = 1.3f;
    public float lookAhead = 4f;
    public float baseFov = 60f;
    public float maxFov = 74f;

    Camera cam;
    float yaw;

    void Awake() { cam = GetComponent<Camera>(); }

    public void SnapToTarget()
    {
        if (target == null) return;
        yaw = target.eulerAngles.y;
        Apply();
    }

    void LateUpdate()
    {
        if (target == null) return;
        yaw = Mathf.LerpAngle(yaw, target.eulerAngles.y, 1f - Mathf.Exp(-yawSmooth * Time.deltaTime));
        Apply();
        if (car != null)
        {
            float ratio = Mathf.Clamp01(car.SpeedKmh / 100f);
            cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, Mathf.Lerp(baseFov, maxFov, ratio), 1f - Mathf.Exp(-3f * Time.deltaTime));
        }
    }

    void Apply()
    {
        Quaternion yawRot = Quaternion.Euler(0f, yaw, 0f);
        Vector3 pos = target.position + yawRot * offset;
        if (pos.y < 1f) pos.y = 1f;
        transform.position = pos;
        Vector3 focus = target.position + Vector3.up * lookHeight + yawRot * Vector3.forward * lookAhead;
        transform.rotation = Quaternion.LookRotation(focus - pos, Vector3.up);
    }
}

using UnityEngine;

/// <summary>One checkpoint gate. Reports to the CheckpointManager when the car drives through.</summary>
public class Checkpoint : MonoBehaviour
{
    public int index;
    public float distance;
    public CheckpointManager manager;
    public Renderer beam;
    public Material passedMaterial;

    public void MarkPassed()
    {
        if (beam != null && passedMaterial != null) beam.sharedMaterial = passedMaterial;
    }

    void OnTriggerEnter(Collider other)
    {
        if (manager == null) return;
        if (other.GetComponentInParent<CarController>() != null) manager.Reached(this);
    }
}

using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>A UI button that reports "held down" / "released" (works with mouse and touch).</summary>
public class HoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
{
    public Action<bool> onHoldChanged;
    public Image targetImage;
    public Color normalColor = Color.white;
    public Color pressedColor = Color.gray;
    bool held;

    public void OnPointerDown(PointerEventData e) { SetHeld(true); }
    public void OnPointerUp(PointerEventData e) { SetHeld(false); }
    public void OnPointerExit(PointerEventData e) { SetHeld(false); }
    void OnDisable() { SetHeld(false); }

    void SetHeld(bool value)
    {
        if (held == value) return;
        held = value;
        if (targetImage != null) targetImage.color = value ? pressedColor : normalColor;
        if (onHoldChanged != null) onHoldChanged(value);
    }
}

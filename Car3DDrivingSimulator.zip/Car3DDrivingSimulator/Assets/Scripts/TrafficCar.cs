using UnityEngine;

/// <summary>A slow AI car that drives along the road in its lane and stops at endDistance.</summary>
[RequireComponent(typeof(Rigidbody))]
public class TrafficCar : MonoBehaviour
{
    /// <summary>Traffic only moves while the game is being played.</summary>
    public static bool Running;

    public TrackPath path;
    public float distance;
    public float lateral;
    public float speed = 7f;
    public float endDistance = 9999f;

    Rigidbody rb;
    float currentSpeed;

    void Awake() { rb = GetComponent<Rigidbody>(); }

    void FixedUpdate()
    {
        if (!Running || path == null) return;
        float dt = Time.fixedDeltaTime;
        float target = distance < endDistance ? speed : 0f;
        currentSpeed = Mathf.MoveTowards(currentSpeed, target, 4f * dt);
        distance += currentSpeed * dt;
        Vector3 pos, fwd;
        path.Evaluate(distance, lateral, out pos, out fwd);
        rb.MovePosition(pos);
        rb.MoveRotation(Quaternion.LookRotation(fwd, Vector3.up));
    }
}

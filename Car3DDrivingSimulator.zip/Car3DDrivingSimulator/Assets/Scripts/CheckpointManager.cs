using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>Keeps track of which checkpoints were passed (in order) and where to respawn the car.</summary>
public class CheckpointManager : MonoBehaviour
{
    public TrackPath path;
    public List<Checkpoint> checkpoints = new List<Checkpoint>();
    public float respawnDistance = 6f;
    public float respawnLateral = 3f;

    public int Passed { get; private set; }
    public int Total { get { return checkpoints.Count; } }

    /// <summary>Called with (number passed, total).</summary>
    public event Action<int, int> OnCheckpointPassed;

    public void Register(Checkpoint cp) { checkpoints.Add(cp); }

    public void Reached(Checkpoint cp)
    {
        if (cp.index != Passed) return; // must be taken in order
        Passed++;
        cp.MarkPassed();
        respawnDistance = cp.distance + 10f;
        if (OnCheckpointPassed != null) OnCheckpointPassed(Passed, Total);
    }

    public void GetRespawnPose(out Vector3 pos, out Quaternion rot)
    {
        Vector3 fwd;
        path.Evaluate(respawnDistance, respawnLateral, out pos, out fwd);
        pos.y = 0.05f;
        rot = Quaternion.LookRotation(fwd, Vector3.up);
    }
}

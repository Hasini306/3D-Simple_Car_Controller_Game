using UnityEngine;

/// <summary>Trigger placed on the finish line. When the car drives through it, the level is completed.</summary>
public class FinishLine : MonoBehaviour
{
    public GameManager gameManager;

    void OnTriggerEnter(Collider other)
    {
        if (gameManager == null) return;
        if (other.GetComponentInParent<CarController>() != null)
            gameManager.CompleteLevel();
    }
}

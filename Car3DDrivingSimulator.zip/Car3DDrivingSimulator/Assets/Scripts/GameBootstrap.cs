using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// The only object stored in the scene. When the game starts it creates the camera rig, light, sky,
/// road, car, traffic, checkpoints, finish line and the whole UI, and connects everything together.
/// </summary>
public class GameBootstrap : MonoBehaviour
{
    GameObject worldRoot;
    GameObject uiRoot;
    Camera cam;
    CameraFollow follow;

    // If you open an empty scene, this still creates the game automatically.
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void EnsureExists()
    {
        if (FindObjectOfType<GameBootstrap>() == null)
            new GameObject("GameBootstrap").AddComponent<GameBootstrap>();
    }

    void Awake()
    {
        Application.targetFrameRate = 60;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Time.timeScale = 1f;
        AudioListener.pause = false;
        MobileCarControls.ResetAll();
        TrafficCar.Running = false;
        QualitySettings.shadowDistance = 90f;

        SetupCameraAndLight();
        if (FindObjectOfType<EventSystem>() == null)
            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        BuildGame(false);
    }

    void SetupCameraAndLight()
    {
        cam = Camera.main;
        if (cam == null)
        {
            GameObject camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            cam = camGO.AddComponent<Camera>();
        }
        if (FindObjectOfType<AudioListener>() == null) cam.gameObject.AddComponent<AudioListener>();
        cam.nearClipPlane = 0.3f;
        cam.farClipPlane = 700f;
        cam.fieldOfView = 60f;
        follow = cam.GetComponent<CameraFollow>();
        if (follow == null) follow = cam.gameObject.AddComponent<CameraFollow>();

        // Sun
        GameObject sunGO = new GameObject("Sun");
        Light sun = sunGO.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.color = new Color(1f, 0.96f, 0.88f);
        sun.intensity = 1.2f;
        sun.shadows = LightShadows.Soft;
        sunGO.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
        RenderSettings.sun = sun;

        // Sky
        Material sky = GameUtil.GetSkybox();
        if (sky != null)
        {
            RenderSettings.skybox = sky;
            cam.clearFlags = CameraClearFlags.Skybox;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Skybox;
        }
        else
        {
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.55f, 0.75f, 0.95f);
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.6f, 0.65f, 0.7f);
        }
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogColor = new Color(0.75f, 0.85f, 0.95f);
        RenderSettings.fogStartDistance = 120f;
        RenderSettings.fogEndDistance = 520f;
        DynamicGI.UpdateEnvironment();
    }

    void BuildGame(bool autoStart)
    {
        worldRoot = new GameObject("GameWorld");
        Transform w = worldRoot.transform;

        TrackPath path = WorldBuilder.CreateTrackPath();

        GameManager gm = worldRoot.AddComponent<GameManager>();
        CheckpointManager cpm = worldRoot.AddComponent<CheckpointManager>();
        cpm.path = path;

        WorldBuilder.BuildEnvironment(w, path);
        WorldBuilder.BuildStart(w, path);
        WorldBuilder.BuildObstacles(w, path);
        WorldBuilder.BuildTraffic(w, path);
        WorldBuilder.BuildCheckpoints(w, path, cpm);
        WorldBuilder.BuildFinish(w, path, gm);

        Vector3 startPos, fwd;
        path.Evaluate(WorldBuilder.StartDistance, WorldBuilder.PlayerLane, out startPos, out fwd);
        startPos.y = 0.05f;
        CarController car = CarBuilder.CreatePlayerCar(w, startPos, Quaternion.LookRotation(fwd, Vector3.up));

        follow.target = car.transform;
        follow.car = car;
        follow.SnapToTarget();

        gm.car = car;
        gm.cameraFollow = follow;
        gm.checkpoints = cpm;
        gm.path = path;
        gm.bootstrap = this;
        gm.startDistance = WorldBuilder.StartDistance;
        gm.finishDistance = WorldBuilder.FinishDistance(path);

        uiRoot = UIBuilder.Build(gm);
        gm.Begin(autoStart);
    }

    public void Restart(bool autoStart)
    {
        StartCoroutine(RestartRoutine(autoStart));
    }

    IEnumerator RestartRoutine(bool autoStart)
    {
        Time.timeScale = 1f;
        AudioListener.pause = false;
        MobileCarControls.ResetAll();
        TrafficCar.Running = false;
        Destroy(worldRoot);
        Destroy(uiRoot);
        yield return null;
        BuildGame(autoStart);
    }
}

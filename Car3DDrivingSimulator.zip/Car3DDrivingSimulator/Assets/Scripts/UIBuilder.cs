using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

/// <summary>Creates the whole user interface (title, HUD, buttons, pause, level completed, game over) in code.</summary>
public static class UIBuilder
{
    static readonly Vector2 Center = new Vector2(0.5f, 0.5f);

    static RectTransform NewRect(string name, Transform parent, Vector2 aMin, Vector2 aMax, Vector2 pivot, Vector2 pos, Vector2 size)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.SetParent(parent, false);
        rt.anchorMin = aMin;
        rt.anchorMax = aMax;
        rt.pivot = pivot;
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return rt;
    }

    static RectTransform Stretch(string name, Transform parent)
    {
        return NewRect(name, parent, Vector2.zero, Vector2.one, Center, Vector2.zero, Vector2.zero);
    }

    static Image NewImage(string name, Transform parent, Vector2 aMin, Vector2 aMax, Vector2 pivot, Vector2 pos, Vector2 size, Color color, bool raycast)
    {
        RectTransform rt = NewRect(name, parent, aMin, aMax, pivot, pos, size);
        Image img = rt.gameObject.AddComponent<Image>();
        img.color = color;
        img.raycastTarget = raycast;
        return img;
    }

    static Text NewText(string name, Transform parent, string text, int fontSize, Color color, TextAnchor align,
        Vector2 aMin, Vector2 aMax, Vector2 pivot, Vector2 pos, Vector2 size)
    {
        RectTransform rt = NewRect(name, parent, aMin, aMax, pivot, pos, size);
        Text t = rt.gameObject.AddComponent<Text>();
        t.font = GameUtil.UIFont;
        t.text = text;
        t.fontSize = fontSize;
        t.fontStyle = FontStyle.Bold;
        t.color = color;
        t.alignment = align;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        rt.gameObject.AddComponent<Shadow>();
        return t;
    }

    static Text CenterText(string name, Transform parent, string text, int fontSize, Color color, Vector2 pos, Vector2 size)
    {
        return NewText(name, parent, text, fontSize, color, TextAnchor.MiddleCenter, Center, Center, Center, pos, size);
    }

    static RectTransform Bar(Transform parent, string name, Vector2 aMin, Vector2 aMax, Vector2 pivot, Vector2 pos, Vector2 size,
        Color bg, Color fill, out Image fillImage)
    {
        Image bgImg = NewImage(name, parent, aMin, aMax, pivot, pos, size, bg, false);
        Image f = NewImage(name + "Fill", bgImg.transform, Vector2.zero, Vector2.one, Center, Vector2.zero, Vector2.zero, fill, false);
        fillImage = f;
        return f.rectTransform;
    }

    static Button MakeButton(Transform parent, string label, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size,
        Color color, int fontSize, UnityAction onClick)
    {
        Image img = NewImage(label + "Button", parent, anchor, anchor, pivot, pos, size, color, true);
        Button b = img.gameObject.AddComponent<Button>();
        b.targetGraphic = img;
        b.onClick.AddListener(onClick);
        NewText("Label", img.transform, label, fontSize, Color.white, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Center, Vector2.zero, Vector2.zero);
        return b;
    }

    static void MakeHold(Transform parent, string label, Vector2 anchor, Vector2 pos, Vector2 size, Color color, int fontSize,
        System.Action<bool> callback)
    {
        Color normal = new Color(color.r, color.g, color.b, 0.7f);
        Color pressed = new Color(Mathf.Min(1f, color.r + 0.25f), Mathf.Min(1f, color.g + 0.25f), Mathf.Min(1f, color.b + 0.25f), 1f);
        Image img = NewImage(label + "Hold", parent, anchor, anchor, anchor, pos, size, normal, true);
        HoldButton hb = img.gameObject.AddComponent<HoldButton>();
        hb.targetImage = img;
        hb.normalColor = normal;
        hb.pressedColor = pressed;
        hb.onHoldChanged = callback;
        NewText("Label", img.transform, label, fontSize, Color.white, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one, Center, Vector2.zero, Vector2.zero);
    }

    static GameObject Overlay(string name, Transform parent, Color color)
    {
        Image img = NewImage(name, parent, Vector2.zero, Vector2.one, Center, Vector2.zero, Vector2.zero, color, true);
        return img.gameObject;
    }

    public static GameObject Build(GameManager gm)
    {
        GameObject root = new GameObject("GameUI");
        Canvas canvas = root.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 10;
        CanvasScaler scaler = root.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;
        root.AddComponent<GraphicRaycaster>();
        Transform c = root.transform;

        Vector2 TL = new Vector2(0f, 1f), TR = new Vector2(1f, 1f), TC = new Vector2(0.5f, 1f);
        Vector2 BL = new Vector2(0f, 0f), BR = new Vector2(1f, 0f), BC = new Vector2(0.5f, 0f);
        Color panelDark = new Color(0f, 0f, 0f, 0.5f);
        Color white = Color.white;
        Color gold = new Color(1f, 0.85f, 0.2f);

        // ================================================================ HUD
        RectTransform hud = Stretch("HUD", c);
        gm.hudPanel = hud.gameObject;

        // Speedometer (top-left)
        Image speedBg = NewImage("SpeedPanel", hud, TL, TL, TL, new Vector2(30f, -30f), new Vector2(380f, 170f), panelDark, false);
        Text speedText = NewText("SpeedValue", speedBg.transform, "0", 100, white, TextAnchor.MiddleRight, TL, TL, TL, new Vector2(10f, -5f), new Vector2(240f, 120f));
        NewText("SpeedUnit", speedBg.transform, "km/h", 36, white, TextAnchor.MiddleLeft, TL, TL, TL, new Vector2(265f, -45f), new Vector2(110f, 50f));
        Image speedFillImg;
        RectTransform speedFill = Bar(speedBg.transform, "SpeedBar", BL, BL, BL, new Vector2(20f, 18f), new Vector2(340f, 22f),
            new Color(0.15f, 0.15f, 0.15f, 0.9f), Color.green, out speedFillImg);
        Speedometer sp = speedBg.gameObject.AddComponent<Speedometer>();
        sp.car = gm.car;
        sp.speedText = speedText;
        sp.barFill = speedFill;
        sp.barImage = speedFillImg;

        // Progress (top-centre)
        Image progBg = NewImage("ProgressPanel", hud, TC, TC, TC, new Vector2(0f, -30f), new Vector2(760f, 125f), panelDark, false);
        gm.distanceText = NewText("DistanceText", progBg.transform, "", 34, white, TextAnchor.MiddleCenter, TC, TC, TC, new Vector2(0f, -8f), new Vector2(740f, 44f));
        gm.checkpointText = NewText("CheckpointText", progBg.transform, "", 28, gold, TextAnchor.MiddleLeft, TL, TL, TL, new Vector2(20f, -52f), new Vector2(360f, 36f));
        gm.timeText = NewText("TimeText", progBg.transform, "", 28, gold, TextAnchor.MiddleRight, TR, TR, TR, new Vector2(-20f, -52f), new Vector2(300f, 36f));
        Image progFillImg;
        gm.progressFill = Bar(progBg.transform, "ProgressBar", BC, BC, BC, new Vector2(0f, 14f), new Vector2(720f, 22f),
            new Color(0.15f, 0.15f, 0.15f, 0.9f), new Color(0.25f, 0.7f, 1f), out progFillImg);

        gm.messageText = NewText("Message", hud, "", 52, gold, TextAnchor.MiddleCenter, TC, TC, TC, new Vector2(0f, -175f), new Vector2(1400f, 70f));

        // Pause button + health (top-right)
        MakeButton(hud, "PAUSE", TR, TR, new Vector2(-30f, -30f), new Vector2(190f, 80f), new Color(0.15f, 0.15f, 0.2f, 0.85f), 40, gm.Pause);
        Image healthBg = NewImage("HealthPanel", hud, TR, TR, TR, new Vector2(-30f, -125f), new Vector2(320f, 80f), panelDark, false);
        gm.healthText = NewText("HealthText", healthBg.transform, "CAR 100%", 26, white, TextAnchor.MiddleCenter, TC, TC, TC, new Vector2(0f, -4f), new Vector2(300f, 34f));
        Image healthFillImg;
        gm.healthFill = Bar(healthBg.transform, "HealthBar", BC, BC, BC, new Vector2(0f, 12f), new Vector2(290f, 24f),
            new Color(0.15f, 0.15f, 0.15f, 0.9f), Color.green, out healthFillImg);
        gm.healthFillImage = healthFillImg;

        NewText("Hint", hud, "W/S or Up/Down = Gas/Reverse    A/D or Left/Right = Steer    Space = Brake    Esc/P = Pause",
            24, new Color(1f, 1f, 1f, 0.75f), TextAnchor.MiddleCenter, BC, BC, BC, new Vector2(0f, 10f), new Vector2(1500f, 34f));

        // On-screen driving buttons
        RectTransform controls = Stretch("MobileControls", hud);
        MobileCarControls mc = controls.gameObject.AddComponent<MobileCarControls>();
        MakeHold(controls, "<", BL, new Vector2(40f, 60f), new Vector2(200f, 200f), new Color(0.2f, 0.35f, 0.7f), 110, mc.SetLeft);
        MakeHold(controls, ">", BL, new Vector2(270f, 60f), new Vector2(200f, 200f), new Color(0.2f, 0.35f, 0.7f), 110, mc.SetRight);
        MakeHold(controls, "GAS", BR, new Vector2(-40f, 60f), new Vector2(230f, 230f), new Color(0.15f, 0.65f, 0.25f), 60, mc.SetAccelerate);
        MakeHold(controls, "BRAKE", BR, new Vector2(-300f, 60f), new Vector2(210f, 105f), new Color(0.8f, 0.15f, 0.15f), 36, mc.SetBrake);
        MakeHold(controls, "REVERSE", BR, new Vector2(-300f, 185f), new Vector2(210f, 105f), new Color(0.85f, 0.55f, 0.1f), 32, mc.SetReverse);

        Image flash = NewImage("DamageFlash", hud, Vector2.zero, Vector2.one, Center, Vector2.zero, Vector2.zero, new Color(1f, 0f, 0f, 0f), false);
        gm.damageFlash = flash;

        // ================================================================ TITLE
        GameObject title = Overlay("TitlePanel", c, new Color(0.02f, 0.05f, 0.12f, 0.6f));
        gm.titlePanel = title;
        CenterText("Title", title.transform, "3D CAR DRIVING SIMULATOR", 100, gold, new Vector2(0f, 270f), new Vector2(1700f, 150f));
        CenterText("Subtitle", title.transform, "Drive to the finish line. Pass every checkpoint and avoid the traffic!", 40, white, new Vector2(0f, 170f), new Vector2(1600f, 60f));
        CenterText("Controls", title.transform,
            "W / Up = Accelerate      S / Down = Reverse\nA / Left = Steer Left      D / Right = Steer Right\nSpace = Brake      Esc or P = Pause\n(The on-screen buttons work too)",
            32, new Color(0.85f, 0.9f, 1f), new Vector2(0f, 20f), new Vector2(1400f, 190f));
        MakeButton(title.transform, "START GAME", Center, Center, new Vector2(0f, -170f), new Vector2(520f, 130f), new Color(0.15f, 0.65f, 0.25f), 56, gm.StartGame);
#if !UNITY_WEBGL
        MakeButton(title.transform, "QUIT", Center, Center, new Vector2(0f, -320f), new Vector2(320f, 90f), new Color(0.5f, 0.15f, 0.15f), 40, gm.QuitGame);
#endif

        // ================================================================ PAUSE
        GameObject pause = Overlay("PausePanel", c, new Color(0f, 0f, 0f, 0.65f));
        gm.pausePanel = pause;
        CenterText("PausedTitle", pause.transform, "PAUSED", 100, white, new Vector2(0f, 240f), new Vector2(1000f, 140f));
        MakeButton(pause.transform, "RESUME", Center, Center, new Vector2(0f, 80f), new Vector2(520f, 110f), new Color(0.15f, 0.65f, 0.25f), 48, gm.Resume);
        MakeButton(pause.transform, "RESTART", Center, Center, new Vector2(0f, -60f), new Vector2(520f, 110f), new Color(0.8f, 0.5f, 0.1f), 48, gm.RestartLevel);
        MakeButton(pause.transform, "MAIN MENU", Center, Center, new Vector2(0f, -200f), new Vector2(520f, 110f), new Color(0.25f, 0.3f, 0.6f), 48, gm.GoToMainMenu);

        // ================================================================ LEVEL COMPLETED
        GameObject done = Overlay("CompletePanel", c, new Color(0.02f, 0.2f, 0.05f, 0.75f));
        gm.completePanel = done;
        CenterText("CompleteTitle", done.transform, "LEVEL COMPLETED!", 110, gold, new Vector2(0f, 260f), new Vector2(1600f, 150f));
        gm.completeStatsText = CenterText("Stats", done.transform, "", 48, white, new Vector2(0f, 60f), new Vector2(1000f, 240f));
        MakeButton(done.transform, "PLAY AGAIN", Center, Center, new Vector2(0f, -150f), new Vector2(520f, 110f), new Color(0.15f, 0.65f, 0.25f), 48, gm.RestartLevel);
        MakeButton(done.transform, "MAIN MENU", Center, Center, new Vector2(0f, -290f), new Vector2(520f, 110f), new Color(0.25f, 0.3f, 0.6f), 48, gm.GoToMainMenu);

        // ================================================================ GAME OVER
        GameObject over = Overlay("GameOverPanel", c, new Color(0.25f, 0.02f, 0.02f, 0.75f));
        gm.gameOverPanel = over;
        CenterText("OverTitle", over.transform, "GAME OVER", 110, new Color(1f, 0.35f, 0.3f), new Vector2(0f, 250f), new Vector2(1400f, 150f));
        CenterText("OverText", over.transform, "Your car is wrecked!", 48, white, new Vector2(0f, 130f), new Vector2(1000f, 70f));
        MakeButton(over.transform, "RETRY FROM CHECKPOINT", Center, Center, new Vector2(0f, -20f), new Vector2(760f, 110f), new Color(0.15f, 0.65f, 0.25f), 44, gm.RetryFromCheckpoint);
        MakeButton(over.transform, "RESTART LEVEL", Center, Center, new Vector2(0f, -160f), new Vector2(760f, 110f), new Color(0.8f, 0.5f, 0.1f), 44, gm.RestartLevel);
        MakeButton(over.transform, "MAIN MENU", Center, Center, new Vector2(0f, -300f), new Vector2(760f, 110f), new Color(0.25f, 0.3f, 0.6f), 44, gm.GoToMainMenu);

        return root;
    }
}
